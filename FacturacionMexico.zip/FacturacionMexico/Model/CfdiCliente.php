<?php
/**
 * This file is part of FacturacionMexico plugin for FacturaScripts
 * Copyright (C) 2019 Juan José Prieto Dzul <juanjoseprieto88@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Plugins\FacturacionMexico\Model;

use FacturaScripts\Core\Session;
use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Plugins\FacturacionMexico\Lib\Cfdi\Shared\CfdiScope;
use FacturaScripts\Plugins\FacturacionMexico\Lib\Cfdi\Shared\Storage\CfdiStorage;
use FacturaScripts\Plugins\FacturacionMexico\Model\Base\CfdiTrait;

class CfdiCliente extends ModelClass
{
    use ModelTrait;
    use CfdiTrait;

    public $codcliente;

    public $idfactura;

    /**
     * @var string
     */
    public $cfdiglobal;

    public function clear(): void
    {
        parent::clear();

        $this->created_at = Tools::dateTime();
        $this->nick = Session::user()->nick;
        $this->cfdiglobal = false;
    }

    public function getXml(): string
    {
        if (!$this->id) {
            return "";
        }

        $xml = CfdiStorage::get()->get(CfdiScope::CUSTOMER, $this->uuid);
        if ($xml !== null) {
            return $xml;
        }

        $legacyXml = CfdiData::getXmlFromCfdi($this->id);
        if ($legacyXml !== '') {
            return $legacyXml;
        }

        $legacyPath = FS_FOLDER . '/MyFiles/CFDI/customer/' . $this->filename;
        if (!empty($this->filename) && is_file($legacyPath)) {
            return file_get_contents($legacyPath) ?: '';
        }

        return '';
    }

    public static function tableName(): string
    {
        return 'cfdis_clientes';
    }

    public static function searchRelated(string $codcliente, string $tipoComprobante, ?string $fromDate = null, ?string $toDate = null): array
    {
        $where = [
            Where::eq('codcliente', $codcliente)
        ];

        if (!empty($tipoComprobante)) {
            $where[] = Where::eq('tipo', $tipoComprobante);
        }

        return self::all($where);
    }

    public function isStampedSuccessfully(): bool
    {
        return $this->estatus === 'timbrada';
    }
}
