<?php
/**
 * This file is part of FacturacionMexico plugin for FacturaScripts
 * Copyright (C) 2019 Juan José Prieto Dzul <juanjoseprieto88@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Plugins\FacturacionMexico\Model;

use CfdiUtils\Validate\Cfdi33\RecepcionPagos\Pagos\Fecha;
use FacturaScripts\Core\Session;
use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Proveedor;
use FacturaScripts\Plugins\FacturacionMexico\Lib\Cfdi\Shared\CfdiScope;
use FacturaScripts\Plugins\FacturacionMexico\Lib\Cfdi\Shared\Storage\CfdiStorage;
use FacturaScripts\Plugins\FacturacionMexico\Model\Base\CfdiTrait;

class CfdiProveedor extends ModelClass
{
    use ModelTrait;
    use CfdiTrait;

    public const string SUPPLIER_CFDI_BASEPATH = FS_FOLDER . '/MyFiles/CFDI/supplier/';

    /**
     * @var string
     */
    public $codproveedor;


    public function clear(): void
    {
        parent::clear();

        $this->created_at = Tools::dateTime();
        $this->nick = Session::user()->nick;
    }

    public function getSupplier(): Proveedor
    {
        $proveedor = new Proveedor();
        $proveedor->load($this->codproveedor);

        return $proveedor;
    }

    public function invoiceNumber(): string
    {
        return $this->serie . $this->folio;
    }

    /**
     * @return string
     */
    public function getFechaEmision(): string
    {
        return $this->fecha_emision;
    }

    public function validateFile(): bool
    {
        return CfdiStorage::get()->exists(CfdiScope::SUPPLIER, $this->uuid)
            || (!empty($this->filename) && is_file(self::SUPPLIER_CFDI_BASEPATH . $this->filename));
    }

    public function localFileContent(): string
    {
        $xml = CfdiStorage::get()->get(CfdiScope::SUPPLIER, $this->uuid);
        if ($xml !== null) {
            return $xml;
        }

        if (!empty($this->filename)) {
            return file_get_contents(self::SUPPLIER_CFDI_BASEPATH . $this->filename) ?: '';
        }

        return '';
    }

    public static function tableName(): string
    {
        return 'cfdis_proveedores';
    }

    public static function primaryColumn(): string
    {
        return 'id';
    }

    public function url(string $type = 'auto', string $list = 'List'): string
    {
        if ($type === 'wizard') {
            $value = $this->id();

            return 'CfdiSupplierWizard?type=' . rawurlencode($this->tipo) . '&code=' . rawurlencode($value);
        }

        return parent::url($type, $list);
    }
}
